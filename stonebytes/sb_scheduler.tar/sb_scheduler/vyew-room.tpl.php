<div class='vyew-room'><? print $vyew_room_link; ?></div>

