<span class='basic-field<? print ($class ? " $class" : ""); ?>'><strong><? print $title; ?>:</strong> <? print $content; ?></span>
