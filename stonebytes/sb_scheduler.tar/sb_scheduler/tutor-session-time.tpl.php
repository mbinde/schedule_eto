<div class='tutor-time tutor-time-<? print $class; ?>'>
  <? print $date; ?> (<?print $interval;?>)<br>
  <em><? print $description; ?></em>
  <? print $cancellations; ?>
</div>