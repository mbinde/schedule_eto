<table class='meeting-participants'>
<tr>
   <td><strong>Tutor: </strong> <? print $tutor; ?></td>
   <td><strong>Students: </strong> <? print $students; ?></td>
</tr>
</table>

